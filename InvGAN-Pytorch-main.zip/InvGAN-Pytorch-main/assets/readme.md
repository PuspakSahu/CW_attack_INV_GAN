This folder contains the media files.
